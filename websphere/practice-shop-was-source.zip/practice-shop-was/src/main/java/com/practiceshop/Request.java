package com.practiceshop;

import java.util.Map;

/** One HTTP request, reduced to what the shop needs. Keeps the shop logic independent of the servlet API. */
public class Request {
    public final String method;
    public final String path; // path inside the application, for example /cart/items/5
    public final Map<String, String> query;
    public final String authorization;
    public final String resetKey;
    public final String body;

    public Request(String method, String path, Map<String, String> query, String authorization, String resetKey, String body) {
        this.method = method;
        this.path = path;
        this.query = query;
        this.authorization = authorization;
        this.resetKey = resetKey;
        this.body = body;
    }
}
