package com.practiceshop;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/** Receives every API request, passes it to {@link Api} and writes the JSON answer. */
public class ShopServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final int MAX_BODY = 64 * 1024;

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        if (req.getCharacterEncoding() == null) {
            req.setCharacterEncoding("UTF-8"); // so query text such as a search for non-English words is read correctly
        }
        String path = req.getRequestURI().substring(req.getContextPath().length());
        int semi = path.indexOf(';'); // drop any ;jsessionid=...
        if (semi >= 0) {
            path = path.substring(0, semi);
        }
        Map<String, String> query = new HashMap<String, String>();
        // Only the query string counts as parameters; the body is always JSON.
        if (req.getQueryString() != null) {
            Enumeration<String> names = req.getParameterNames();
            while (names.hasMoreElements()) {
                String name = names.nextElement();
                query.put(name, req.getParameter(name));
            }
        }
        String body = null;
        Result result;
        try {
            body = readBody(req);
            result = Api.handle(new Request(req.getMethod().toUpperCase(), path, query, req.getHeader("Authorization"),
                    req.getHeader("X-Reset-Key"), body));
        } catch (BodyTooLarge e) {
            result = new Result(413, "{\"detail\":\"Request body is too large\"}");
        }
        byte[] out = result.json.getBytes(StandardCharsets.UTF_8);
        resp.setStatus(result.status);
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.setHeader("Cache-Control", "no-store");
        resp.setContentLength(out.length);
        resp.getOutputStream().write(out);
    }

    private static String readBody(HttpServletRequest req) throws IOException {
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        InputStream in = req.getInputStream();
        byte[] chunk = new byte[4096];
        int n;
        while ((n = in.read(chunk)) != -1) {
            buf.write(chunk, 0, n);
            if (buf.size() > MAX_BODY) {
                throw new BodyTooLarge();
            }
        }
        return buf.size() == 0 ? null : new String(buf.toByteArray(), StandardCharsets.UTF_8);
    }

    private static final class BodyTooLarge extends IOException {
        private static final long serialVersionUID = 1L;
    }
}
