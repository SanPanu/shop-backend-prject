#!/bin/sh
# Builds build/practice-shop.war with only a JDK (8 or newer). Maven users can run "mvn package" instead.
#   SERVLET_API  jar that contains the javax.servlet 3.1 API (compile time only; WebSphere provides it at run time)
set -e
cd "$(dirname "$0")"
: "${SERVLET_API:?Set SERVLET_API to a jar containing the javax.servlet 3.1 API}"
rm -rf build/classes build/war && mkdir -p build/classes build/war/WEB-INF/lib
RELEASE="--release 8"
javac --release 8 -version >/dev/null 2>&1 || RELEASE="-source 1.8 -target 1.8"
javac $RELEASE -encoding UTF-8 -Xlint:all -Xlint:-options -cp "$SERVLET_API:lib/gson-2.10.jar" -d build/classes $(find src/main/java -name '*.java')
cp src/main/resources/seed.json build/classes/
cp -r src/main/webapp/. build/war/
cp -r build/classes build/war/WEB-INF/classes
cp lib/gson-2.10.jar build/war/WEB-INF/lib/
(cd build/war && jar cf ../practice-shop.war .)
echo "Built build/practice-shop.war"
