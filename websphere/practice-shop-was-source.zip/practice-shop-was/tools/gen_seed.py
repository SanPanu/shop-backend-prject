"""Writes the seed data for the Java application (seed.json) and the Oracle script (db/shop_oracle.sql)
from the Python shop's seed module, so both versions of the shop start from identical data."""
import json
import sys
from pathlib import Path

sys.path.insert(0, sys.argv[1])  # path to the Python shop
from app import seed  # noqa: E402

root = Path(__file__).resolve().parent.parent
users = [
    {"id": 1, "email": "alice@example.com", "name": "Alice", "password_hash": seed.hash_password(seed.SEED_PASSWORD)},
    {"id": 2, "email": "bob@example.com", "name": "Bob", "password_hash": seed.hash_password(seed.SEED_PASSWORD)},
]
products = [
    {"id": i, "name": n, "category": c, "description": f"{n}. {sp.replace(' • ', ', ')}.", "specs": sp, "price": p, "mrp": m,
     "stock": s, "rating": r, "reviews": rv, "image": img}
    for i, n, c, p, m, s, sp, r, rv, img in seed.PRODUCTS
]
coupons = [
    {"code": c.code, "kind": c.kind, "amount": c.value, "min_order": c.min_order or 0, "active": c.active is not False,
     "expires_at": c.expires_at.strftime("%Y-%m-%d %H:%M:%S") if c.expires_at else None}
    for c in seed.COUPONS
]
(root / "src/main/resources/seed.json").write_text(
    json.dumps({"users": users, "products": products, "coupons": coupons}, indent=1, ensure_ascii=False), encoding="utf-8")


def lit(v):
    """An Oracle literal. Non-ASCII text uses UNISTR so the script is plain ASCII and safe in any client encoding."""
    if v is None:
        return "NULL"
    if isinstance(v, bool):
        return "1" if v else "0"
    if isinstance(v, (int, float)):
        return str(v)
    if all(ord(ch) < 128 for ch in v):
        return "'" + v.replace("'", "''") + "'"
    out = "".join(ch if ord(ch) < 128 and ch != "\\" else "\\%04X" % ord(ch) for ch in v)
    return "UNISTR('" + out.replace("'", "''") + "')"


rows = []
for u in users:
    rows.append("INSERT INTO shop_users (id, email, name, password_hash) VALUES (%s, %s, %s, %s);"
                % (u["id"], lit(u["email"]), lit(u["name"]), lit(u["password_hash"])))
rows.append("")
for p in products:
    rows.append("INSERT INTO shop_products (id, name, category, description, specs, price, mrp, stock, rating, reviews, image) VALUES "
                "(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);" % tuple(lit(p[k]) for k in
                ["id", "name", "category", "description", "specs", "price", "mrp", "stock", "rating", "reviews", "image"]))
rows.append("")
for c in coupons:
    exp = "TIMESTAMP '%s'" % c["expires_at"] if c["expires_at"] else "NULL"
    rows.append("INSERT INTO shop_coupons (code, kind, amount, min_order, active, expires_at) VALUES (%s, %s, %s, %s, %s, %s);"
                % (lit(c["code"]), lit(c["kind"]), c["amount"], c["min_order"], lit(c["active"]), exp))
rows.append("")
rows.append("INSERT INTO shop_id_counters (name, next_val) VALUES ('users', %d);" % (max(u["id"] for u in users) + 1))
for name in ["orders", "order_items", "cart_items"]:
    rows.append("INSERT INTO shop_id_counters (name, next_val) VALUES ('%s', 1);" % name)

schema = (root / "db/schema.part.sql").read_text(encoding="utf-8")
script = schema.rstrip() + "\n\n-- ===================================================================== SEED DATA\n" + "\n".join(rows) + "\n\nCOMMIT;\n"
script.encode("ascii")  # fails loudly if anything non-ASCII slipped in
(root / "db/shop_oracle.sql").write_text(script, encoding="ascii")
print("users %d, products %d, coupons %d" % (len(users), len(products), len(coupons)))
