package com.practiceshop;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/** Database access. On WebSphere the connection comes from the data source bound to jdbc/ShopDS. */
public final class Db {
    public static final String JNDI_NAME = "java:comp/env/jdbc/ShopDS";
    private static volatile DataSource dataSource;

    private Db() {
    }

    public static Connection open() throws SQLException {
        // Outside an application server (local runs and tests) a plain JDBC URL can be given instead.
        String url = System.getProperty("shop.jdbc.url");
        Connection c;
        if (url != null && !url.isEmpty()) {
            c = DriverManager.getConnection(url, System.getProperty("shop.jdbc.user", ""), System.getProperty("shop.jdbc.password", ""));
        } else {
            c = lookup().getConnection();
        }
        c.setAutoCommit(false);
        return c;
    }

    private static DataSource lookup() throws SQLException {
        DataSource ds = dataSource;
        if (ds == null) {
            try {
                ds = (DataSource) new InitialContext().lookup(JNDI_NAME);
            } catch (NamingException e) {
                throw new SQLException("Data source " + JNDI_NAME + " was not found. Map the resource reference jdbc/ShopDS "
                        + "to a data source when installing the application. (" + e.getMessage() + ")", e);
            }
            dataSource = ds;
        }
        return ds;
    }

    public static void rollback(Connection c) {
        if (c != null) {
            try {
                c.rollback();
            } catch (SQLException ignored) {
                // the original error is the one worth reporting
            }
        }
    }

    public static void close(Connection c) {
        if (c != null) {
            try {
                c.setAutoCommit(true);
            } catch (SQLException ignored) {
                // closing anyway
            }
            try {
                c.close();
            } catch (SQLException ignored) {
                // nothing more to do
            }
        }
    }

    /** Prepare a statement and bind its parameters. Supports String, Integer, Long, Double, Timestamp and null. */
    public static PreparedStatement ps(Connection c, String sql, Object... args) throws SQLException {
        PreparedStatement p = c.prepareStatement(sql);
        for (int i = 0; i < args.length; i++) {
            Object a = args[i];
            if (a == null) {
                p.setNull(i + 1, Types.VARCHAR);
            } else if (a instanceof Integer) {
                p.setInt(i + 1, (Integer) a);
            } else if (a instanceof Long) {
                p.setLong(i + 1, (Long) a);
            } else if (a instanceof Double) {
                p.setDouble(i + 1, (Double) a);
            } else if (a instanceof Timestamp) {
                p.setTimestamp(i + 1, (Timestamp) a);
            } else {
                p.setString(i + 1, a.toString());
            }
        }
        return p;
    }

    public static int update(Connection c, String sql, Object... args) throws SQLException {
        try (PreparedStatement p = ps(c, sql, args)) {
            return p.executeUpdate();
        }
    }

    /** Next id for a table. The counter row is locked until the transaction ends, so ids are never handed out twice. */
    public static int nextId(Connection c, String table) throws SQLException {
        if (update(c, "UPDATE shop_id_counters SET next_val = next_val + 1 WHERE name = ?", table) != 1) {
            throw new SQLException("No id counter for " + table + ". Was the database script run?");
        }
        try (PreparedStatement p = ps(c, "SELECT next_val FROM shop_id_counters WHERE name = ?", table);
                java.sql.ResultSet rs = p.executeQuery()) {
            rs.next();
            return rs.getInt(1) - 1;
        }
    }
}
