package com.practiceshop;

/** An error that is sent to the caller as an HTTP status and a JSON "detail". */
public class ApiException extends RuntimeException {
    private static final long serialVersionUID = 1L;
    public final int status;
    public final transient Object detail; // String, or a JsonArray of field errors for 422

    public ApiException(int status, Object detail) {
        super(String.valueOf(detail));
        this.status = status;
        this.detail = detail;
    }
}
