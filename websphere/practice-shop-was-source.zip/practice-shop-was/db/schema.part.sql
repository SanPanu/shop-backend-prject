-- =====================================================================================
-- Practice Shop: tables and seed data for Oracle Database 12c or newer.
--
-- Run this while connected as the schema owner (for example SHOP), in SQL*Plus, SQLcl or
-- SQL Developer:      sqlplus shop/your_password@//dbhost:1521/ORCLPDB1 @shop_oracle.sql
--
-- To start again from nothing, run shop_oracle_drop.sql first.
-- The file is plain ASCII; the bullet character in product specs is written with UNISTR.
-- =====================================================================================

-- ===================================================================== TABLES
CREATE TABLE shop_users (
  id             NUMBER(10)          NOT NULL,
  email          VARCHAR2(255)       NOT NULL,
  name           VARCHAR2(100 CHAR)  NOT NULL,
  password_hash  VARCHAR2(64)        NOT NULL,
  CONSTRAINT shop_users_pk PRIMARY KEY (id),
  CONSTRAINT shop_users_email_uq UNIQUE (email)
);

CREATE TABLE shop_tokens (
  token    VARCHAR2(64)  NOT NULL,
  user_id  NUMBER(10)    NOT NULL,
  CONSTRAINT shop_tokens_pk PRIMARY KEY (token),
  CONSTRAINT shop_tokens_user_fk FOREIGN KEY (user_id) REFERENCES shop_users (id)
);

CREATE INDEX shop_tokens_user_ix ON shop_tokens (user_id);

CREATE TABLE shop_products (
  id           NUMBER(10)           NOT NULL,
  name         VARCHAR2(200 CHAR)   NOT NULL,
  category     VARCHAR2(50)         NOT NULL,
  description  VARCHAR2(1000 CHAR),
  specs        VARCHAR2(200 CHAR),
  price        NUMBER(10)           NOT NULL,
  mrp          NUMBER(10)           NOT NULL,
  stock        NUMBER(10)           NOT NULL,
  rating       NUMBER(2,1)          DEFAULT 0 NOT NULL,
  reviews      NUMBER(10)           DEFAULT 0 NOT NULL,
  image        VARCHAR2(200),
  CONSTRAINT shop_products_pk PRIMARY KEY (id),
  CONSTRAINT shop_products_price_ck CHECK (price > 0 AND mrp >= price),
  CONSTRAINT shop_products_stock_ck CHECK (stock >= 0)
);

CREATE INDEX shop_products_category_ix ON shop_products (category);

CREATE TABLE shop_cart_items (
  id          NUMBER(10)  NOT NULL,
  user_id     NUMBER(10)  NOT NULL,
  product_id  NUMBER(10)  NOT NULL,
  quantity    NUMBER(10)  NOT NULL,
  CONSTRAINT shop_cart_items_pk PRIMARY KEY (id),
  CONSTRAINT shop_cart_items_uq UNIQUE (user_id, product_id),
  CONSTRAINT shop_cart_items_user_fk FOREIGN KEY (user_id) REFERENCES shop_users (id),
  CONSTRAINT shop_cart_items_product_fk FOREIGN KEY (product_id) REFERENCES shop_products (id),
  CONSTRAINT shop_cart_items_qty_ck CHECK (quantity > 0)
);

CREATE TABLE shop_coupons (
  code        VARCHAR2(30)  NOT NULL,
  kind        VARCHAR2(10)  NOT NULL,
  amount      NUMBER(10)    NOT NULL,
  min_order   NUMBER(10)    DEFAULT 0 NOT NULL,
  active      NUMBER(1)     DEFAULT 1 NOT NULL,
  expires_at  TIMESTAMP,
  CONSTRAINT shop_coupons_pk PRIMARY KEY (code),
  CONSTRAINT shop_coupons_kind_ck CHECK (kind IN ('percent', 'flat')),
  CONSTRAINT shop_coupons_active_ck CHECK (active IN (0, 1))
);

CREATE TABLE shop_orders (
  id           NUMBER(10)    NOT NULL,
  user_id      NUMBER(10)    NOT NULL,
  subtotal     NUMBER(12)    NOT NULL,
  discount     NUMBER(12)    DEFAULT 0 NOT NULL,
  total        NUMBER(12)    NOT NULL,
  coupon_code  VARCHAR2(30),
  status       VARCHAR2(20)  DEFAULT 'paid' NOT NULL,
  shipping     CLOB,
  created_at   TIMESTAMP     NOT NULL,
  CONSTRAINT shop_orders_pk PRIMARY KEY (id),
  CONSTRAINT shop_orders_user_fk FOREIGN KEY (user_id) REFERENCES shop_users (id),
  CONSTRAINT shop_orders_status_ck CHECK (status IN ('paid', 'cancelled'))
);

CREATE INDEX shop_orders_user_ix ON shop_orders (user_id);

CREATE TABLE shop_order_items (
  id          NUMBER(10)          NOT NULL,
  order_id    NUMBER(10)          NOT NULL,
  product_id  NUMBER(10)          NOT NULL,
  name        VARCHAR2(200 CHAR)  NOT NULL,
  unit_price  NUMBER(10)          NOT NULL,
  quantity    NUMBER(10)          NOT NULL,
  CONSTRAINT shop_order_items_pk PRIMARY KEY (id),
  CONSTRAINT shop_order_items_order_fk FOREIGN KEY (order_id) REFERENCES shop_orders (id),
  CONSTRAINT shop_order_items_product_fk FOREIGN KEY (product_id) REFERENCES shop_products (id)
);

CREATE INDEX shop_order_items_order_ix ON shop_order_items (order_id);

-- The application hands out ids from this table instead of identity columns or sequences,
-- so that "reset to seed data" can restart the numbering (order #1 again) on every Oracle version.
CREATE TABLE shop_id_counters (
  name      VARCHAR2(30)  NOT NULL,
  next_val  NUMBER(10)    NOT NULL,
  CONSTRAINT shop_id_counters_pk PRIMARY KEY (name)
);
