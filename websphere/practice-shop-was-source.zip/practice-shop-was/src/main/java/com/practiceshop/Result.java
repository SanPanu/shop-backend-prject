package com.practiceshop;

public class Result {
    public final int status;
    public final String json;

    public Result(int status, String json) {
        this.status = status;
        this.json = json;
    }
}
