package com.practiceshop;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

/**
 * The shop's REST API. Each request runs in one database transaction: it is committed when the request
 * succeeds and rolled back when it ends in an error.
 */
public final class Api {
    private static final Logger LOG = Logger.getLogger(Api.class.getName());
    static final Gson GSON = new GsonBuilder().serializeNulls().disableHtmlEscaping().create();
    static final int MAX_INT = 2147483647; // largest id, price or quantity accepted
    static final String DECLINED_CARD = "4000000000000002"; // mock payment: this card is always declined

    private static final Pattern EMAIL = Pattern.compile("^[^@\\s]+@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)+$");
    private static final Pattern CARD = Pattern.compile("^[0-9]{16}$");
    private static final Pattern PIN = Pattern.compile("^[1-9][0-9]{5}$");
    private static final Pattern INTEGER = Pattern.compile("^-?[0-9]+$");
    private static final DateTimeFormatter ISO = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSSSS");

    static final String[][] CATEGORIES = { // slug, display name, icon
        {"fashion", "Fashion", "shirt"}, {"mobiles", "Mobiles", "phone"}, {"electronics", "Electronics", "laptop"},
        {"beauty", "Beauty", "flower"}, {"home", "Home", "lamp"}, {"appliances", "Appliances", "washer"},
        {"toys", "Toys", "teddy"}, {"food", "Food", "food"}, {"sports", "Sports", "ball"}, {"books", "Books", "book"},
    };
    static final List<String> COUNTRIES = Collections.singletonList("India");
    static final List<String> STATES = Arrays.asList(
        "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Goa", "Gujarat", "Haryana", "Himachal Pradesh",
        "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha",
        "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal",
        "Andaman and Nicobar Islands", "Chandigarh", "Dadra and Nagar Haveli and Daman and Diu", "Delhi", "Jammu and Kashmir",
        "Ladakh", "Lakshadweep", "Puducherry");

    private static final String PRODUCT_COLUMNS = "id, name, category, description, specs, price, mrp, rating, reviews, image, stock";
    private static final Map<String, String> SORTS = new HashMap<String, String>();

    static {
        SORTS.put("id", "id");
        SORTS.put("price_asc", "price ASC, id");
        SORTS.put("price_desc", "price DESC, id");
        SORTS.put("name", "name, id");
        SORTS.put("discount", "(mrp - price) * 100.0 / mrp DESC, id");
        SORTS.put("rating", "rating DESC, id");
    }

    private Api() {
    }

    static String setting(String name, String fallback) {
        String v = System.getProperty(name);
        if (v == null) {
            v = System.getenv(name);
        }
        return v == null ? fallback : v;
    }

    // ------------------------------------------------------------------ entry point
    public static Result handle(Request r) {
        String[] p = r.path.replaceAll("^/+|/+$", "").split("/");
        try {
            Result quick = withoutDatabase(r.method, p);
            if (quick != null) {
                return quick;
            }
        } catch (ApiException e) {
            return error(e);
        }
        Connection c = null;
        try {
            c = Db.open();
        } catch (SQLException e) {
            LOG.log(Level.SEVERE, "Cannot open a database connection", e);
            return new Result(503, detail("Database is not available: " + e.getMessage()));
        }
        try {
            Result res = route(r, p, c);
            c.commit();
            return res;
        } catch (ApiException e) {
            Db.rollback(c);
            return error(e);
        } catch (SQLException e) {
            Db.rollback(c);
            LOG.log(Level.SEVERE, r.method + " " + r.path + " failed", e);
            return new Result(500, detail("Database error: " + e.getMessage()));
        } catch (RuntimeException e) {
            Db.rollback(c);
            LOG.log(Level.SEVERE, r.method + " " + r.path + " failed", e);
            return new Result(500, detail("Internal Server Error"));
        } finally {
            Db.close(c);
        }
    }

    private static Result error(ApiException e) {
        JsonObject o = new JsonObject();
        if (e.detail instanceof JsonElement) {
            o.add("detail", (JsonElement) e.detail);
        } else {
            o.addProperty("detail", String.valueOf(e.detail));
        }
        return new Result(e.status, GSON.toJson(o));
    }

    private static String detail(String text) {
        JsonObject o = new JsonObject();
        o.addProperty("detail", text);
        return GSON.toJson(o);
    }

    private static Result ok(JsonElement body) {
        return new Result(200, GSON.toJson(body));
    }

    private static boolean is(String[] p, String... parts) {
        if (p.length != parts.length) {
            return false;
        }
        for (int i = 0; i < p.length; i++) {
            if (parts[i] != null && !parts[i].equals(p[i])) {
                return false; // a null in the pattern matches any segment
            }
        }
        return true;
    }

    private static void need(String method, String... allowed) {
        if (!Arrays.asList(allowed).contains(method)) {
            throw new ApiException(405, "Method Not Allowed");
        }
    }

    private static Result withoutDatabase(String m, String[] p) {
        if (is(p, "health")) {
            need(m, "GET");
            JsonObject o = new JsonObject();
            o.addProperty("status", "ok");
            return ok(o);
        }
        if (is(p, "shipping", "options")) {
            need(m, "GET");
            JsonObject o = new JsonObject();
            o.add("countries", GSON.toJsonTree(COUNTRIES));
            o.add("states", GSON.toJsonTree(STATES));
            o.addProperty("shipping_fee", 0);
            return ok(o);
        }
        if (is(p, "agent", "status")) { // the chat assistant is not part of the WebSphere build
            need(m, "GET");
            JsonObject o = new JsonObject();
            o.addProperty("enabled", false);
            o.addProperty("configured", false);
            o.add("provider", JsonNull.INSTANCE);
            o.add("model", JsonNull.INSTANCE);
            return ok(o);
        }
        return null;
    }

    private static Result route(Request r, String[] p, Connection c) throws SQLException {
        String m = r.method;
        if (is(p, "health", "db")) {
            need(m, "GET");
            return healthDb(c);
        }
        if (is(p, "test", "reset")) {
            need(m, "POST");
            return reset(r, c);
        }
        if (is(p, "auth", "register")) {
            need(m, "POST");
            return register(r, c);
        }
        if (is(p, "auth", "login")) {
            need(m, "POST");
            return login(r, c);
        }
        if (is(p, "auth", "logout")) {
            need(m, "POST");
            return logout(r, c);
        }
        if (is(p, "me")) {
            need(m, "GET");
            return ok(userJson(user(r, c)));
        }
        if (is(p, "products")) {
            need(m, "GET");
            return ok(listProducts(r, c));
        }
        if (is(p, "products", null)) {
            need(m, "GET");
            return ok(product(c, pathInt(p[1], "product_id")));
        }
        if (is(p, "categories")) {
            need(m, "GET");
            return ok(categories(c));
        }
        if (is(p, "cart")) {
            need(m, "GET", "DELETE");
            JsonObject u = user(r, c);
            if (m.equals("DELETE")) {
                Db.update(c, "DELETE FROM shop_cart_items WHERE user_id = ?", id(u));
            }
            return ok(cart(c, id(u)));
        }
        if (is(p, "cart", "items")) {
            need(m, "POST");
            JsonObject u = user(r, c);
            JsonObject b = body(r);
            int productId = intField(b, "product_id", null, Integer.MIN_VALUE, MAX_INT);
            int quantity = intField(b, "quantity", 1, 1, MAX_INT);
            return ok(setQuantity(c, id(u), productId, quantity, true));
        }
        if (is(p, "cart", "items", null)) {
            need(m, "PUT", "DELETE");
            JsonObject u = user(r, c);
            if (m.equals("PUT")) {
                int quantity = intField(body(r), "quantity", null, 1, MAX_INT);
                return ok(setQuantity(c, id(u), pathInt(p[2], "product_id"), quantity, false));
            }
            int productId = pathInt(p[2], "product_id");
            if (Db.update(c, "DELETE FROM shop_cart_items WHERE user_id = ? AND product_id = ?", id(u), productId) == 0) {
                throw new ApiException(404, "Product is not in the cart");
            }
            return ok(cart(c, id(u)));
        }
        if (is(p, "coupons", "validate")) {
            need(m, "POST");
            return validateCoupon(r, c);
        }
        if (is(p, "checkout")) {
            need(m, "POST");
            return checkout(r, c);
        }
        if (is(p, "orders")) {
            need(m, "GET");
            return ok(orders(c, id(user(r, c))));
        }
        if (is(p, "orders", null)) {
            need(m, "GET");
            JsonObject u = user(r, c);
            return ok(order(c, id(u), pathInt(p[1], "order_id")));
        }
        if (is(p, "orders", null, "cancel")) {
            need(m, "POST");
            JsonObject u = user(r, c);
            return ok(cancelOrder(c, id(u), pathInt(p[1], "order_id")));
        }
        throw new ApiException(404, "Not Found");
    }

    // ------------------------------------------------------------------ input checking
    private static ApiException invalid(String where, String field, String msg) {
        JsonArray loc = new JsonArray();
        loc.add(where);
        loc.add(field);
        JsonObject e = new JsonObject();
        e.add("loc", loc);
        e.addProperty("msg", msg);
        e.addProperty("type", "value_error");
        JsonArray list = new JsonArray();
        list.add(e);
        return new ApiException(422, list);
    }

    private static int pathInt(String raw, String name) {
        return checkedInt("path", name, raw, Integer.MIN_VALUE, MAX_INT);
    }

    private static int checkedInt(String where, String name, String raw, int min, int max) {
        if (raw == null || !INTEGER.matcher(raw).matches()) {
            throw invalid(where, name, "Input should be a valid integer");
        }
        BigInteger v = new BigInteger(raw);
        if (v.compareTo(BigInteger.valueOf(min)) < 0) {
            throw invalid(where, name, "Input should be greater than or equal to " + min);
        }
        if (v.compareTo(BigInteger.valueOf(max)) > 0) {
            throw invalid(where, name, "Input should be less than or equal to " + max);
        }
        return v.intValue();
    }

    private static Integer queryInt(Request r, String name, int min, int max) {
        String raw = r.query.get(name);
        return raw == null ? null : Integer.valueOf(checkedInt("query", name, raw, min, max));
    }

    private static JsonObject body(Request r) {
        if (r.body == null || r.body.trim().isEmpty()) {
            throw invalid("body", "", "Field required");
        }
        try {
            JsonElement e = JsonParser.parseString(r.body);
            if (!e.isJsonObject()) {
                throw invalid("body", "", "Input should be a valid object");
            }
            return e.getAsJsonObject();
        } catch (com.google.gson.JsonParseException e) {
            throw invalid("body", "", "JSON decode error");
        }
    }

    /** A whole number field. A missing field takes the fallback, or is an error when the fallback is null. */
    private static int intField(JsonObject b, String name, Integer fallback, int min, int max) {
        JsonElement e = b.get(name);
        if (e == null) {
            if (fallback == null) {
                throw invalid("body", name, "Field required");
            }
            return fallback;
        }
        if (!e.isJsonPrimitive() || e.getAsJsonPrimitive().isBoolean()) {
            throw invalid("body", name, "Input should be a valid integer");
        }
        JsonPrimitive prim = e.getAsJsonPrimitive();
        String raw;
        if (prim.isNumber()) {
            BigDecimal d;
            try {
                d = new BigDecimal(prim.getAsString());
            } catch (NumberFormatException ex) {
                throw invalid("body", name, "Input should be a valid integer");
            }
            if (d.signum() != 0 && d.stripTrailingZeros().scale() > 0) {
                throw invalid("body", name, "Input should be a valid integer, got a number with a fractional part");
            }
            raw = d.toBigInteger().toString();
        } else {
            raw = prim.getAsString();
        }
        return checkedInt("body", name, raw, min, max);
    }

    /** A text field. Returns null when the field is absent or null and it is not required. */
    private static String strField(JsonObject b, String name, boolean required) {
        JsonElement e = b.get(name);
        if (e == null || e.isJsonNull()) {
            if (required) {
                throw invalid("body", name, e == null ? "Field required" : "Input should be a valid string");
            }
            return null;
        }
        if (!e.isJsonPrimitive() || !e.getAsJsonPrimitive().isString()) {
            throw invalid("body", name, "Input should be a valid string");
        }
        return e.getAsString();
    }

    private static String text(JsonObject b, String name, int max, boolean mayBeBlank) {
        String v = strField(b, name, !mayBeBlank);
        if (v == null) {
            return "";
        }
        if (v.length() > max) {
            throw invalid("body", name, "String should have at most " + max + " characters");
        }
        v = v.trim();
        if (v.isEmpty() && !mayBeBlank) {
            throw invalid("body", name, "This field cannot be blank");
        }
        return v;
    }

    private static String s(ResultSet rs, String column) throws SQLException {
        String v = rs.getString(column);
        return v == null ? "" : v; // Oracle stores an empty string as NULL
    }

    private static int id(JsonObject o) {
        return o.get("id").getAsInt();
    }

    // ------------------------------------------------------------------ system
    private static Result healthDb(Connection c) throws SQLException {
        JsonObject o = new JsonObject();
        try (PreparedStatement ps = Db.ps(c, "SELECT COUNT(*) FROM shop_products"); ResultSet rs = ps.executeQuery()) {
            rs.next();
            o.addProperty("status", "ok");
            o.addProperty("database", c.getMetaData().getDatabaseProductName());
            o.addProperty("products", rs.getInt(1));
        }
        return ok(o);
    }

    private static Result reset(Request r, Connection c) throws SQLException {
        if (!"true".equalsIgnoreCase(setting("ALLOW_RESET", "true"))) {
            throw new ApiException(403, "Reset is disabled");
        }
        String key = setting("RESET_KEY", "practice-reset");
        if (r.resetKey == null || r.resetKey.isEmpty() || !Passwords.same(r.resetKey, key)) {
            throw new ApiException(403, "A valid X-Reset-Key header is required");
        }
        Seed.reset(c);
        JsonObject o = new JsonObject();
        o.addProperty("status", "reset");
        return ok(o);
    }

    // ------------------------------------------------------------------ users and sessions
    private static JsonObject user(Request r, Connection c) throws SQLException {
        String a = r.authorization;
        if (a == null || !a.startsWith("Bearer ")) {
            throw new ApiException(401, "Missing bearer token");
        }
        String sql = "SELECT u.id, u.email, u.name FROM shop_tokens t JOIN shop_users u ON u.id = t.user_id WHERE t.token = ?";
        try (PreparedStatement ps = Db.ps(c, sql, a.substring(7)); ResultSet rs = ps.executeQuery()) {
            if (!rs.next()) {
                throw new ApiException(401, "Invalid token");
            }
            JsonObject u = new JsonObject();
            u.addProperty("id", rs.getInt("id"));
            u.addProperty("email", rs.getString("email"));
            u.addProperty("name", s(rs, "name"));
            return u;
        }
    }

    private static JsonObject userJson(JsonObject u) {
        return u;
    }

    private static Result issueToken(Connection c, JsonObject u, int status) throws SQLException {
        String token = Passwords.newToken();
        Db.update(c, "INSERT INTO shop_tokens (token, user_id) VALUES (?, ?)", token, id(u));
        JsonObject o = new JsonObject();
        o.addProperty("token", token);
        o.add("user", u);
        return new Result(status, GSON.toJson(o));
    }

    private static Result register(Request r, Connection c) throws SQLException {
        JsonObject b = body(r);
        String email = strField(b, "email", true);
        if (email.length() > 255 || !EMAIL.matcher(email).matches()) {
            throw invalid("body", "email", "Enter a valid email address");
        }
        String rawName = strField(b, "name", true);
        if (rawName.isEmpty() || rawName.length() > 100) {
            throw invalid("body", "name", "Name should have 1 to 100 characters");
        }
        String name = rawName.trim();
        if (name.isEmpty()) {
            throw invalid("body", "name", "Name cannot be blank");
        }
        String password = strField(b, "password", true);
        if (password.length() < 8 || password.length() > 100) {
            throw invalid("body", "password", "Password should have 8 to 100 characters");
        }
        if (password.trim().isEmpty()) {
            throw invalid("body", "password", "Password cannot be only spaces");
        }
        email = email.toLowerCase(Locale.ROOT);
        try (PreparedStatement ps = Db.ps(c, "SELECT id FROM shop_users WHERE email = ?", email); ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                throw new ApiException(409, "Email already registered");
            }
        }
        int newId = Db.nextId(c, "users");
        try {
            Db.update(c, "INSERT INTO shop_users (id, email, name, password_hash) VALUES (?, ?, ?, ?)", newId, email, name, Passwords.hash(password));
        } catch (SQLIntegrityConstraintViolationException e) { // registered by another request a moment ago
            throw new ApiException(409, "Email already registered");
        }
        JsonObject u = new JsonObject();
        u.addProperty("id", newId);
        u.addProperty("email", email);
        u.addProperty("name", name);
        return issueToken(c, u, 201);
    }

    private static Result login(Request r, Connection c) throws SQLException {
        JsonObject b = body(r);
        String email = strField(b, "email", true).toLowerCase(Locale.ROOT);
        String password = strField(b, "password", true);
        try (PreparedStatement ps = Db.ps(c, "SELECT id, email, name, password_hash FROM shop_users WHERE email = ?", email);
                ResultSet rs = ps.executeQuery()) {
            if (!rs.next() || !Passwords.same(rs.getString("password_hash"), Passwords.hash(password))) {
                throw new ApiException(401, "Wrong email or password");
            }
            JsonObject u = new JsonObject();
            u.addProperty("id", rs.getInt("id"));
            u.addProperty("email", rs.getString("email"));
            u.addProperty("name", s(rs, "name"));
            return issueToken(c, u, 200);
        }
    }

    private static Result logout(Request r, Connection c) throws SQLException {
        user(r, c);
        Db.update(c, "DELETE FROM shop_tokens WHERE token = ?", r.authorization.substring(7));
        JsonObject o = new JsonObject();
        o.addProperty("status", "logged out");
        return ok(o);
    }

    // ------------------------------------------------------------------ products
    private static JsonObject productJson(ResultSet rs) throws SQLException {
        int price = rs.getInt("price");
        int mrp = rs.getInt("mrp");
        int stock = rs.getInt("stock");
        JsonObject o = new JsonObject();
        o.addProperty("id", rs.getInt("id"));
        o.addProperty("name", s(rs, "name"));
        o.addProperty("category", s(rs, "category"));
        o.addProperty("description", s(rs, "description"));
        o.addProperty("specs", s(rs, "specs"));
        o.addProperty("price", price);
        o.addProperty("mrp", mrp);
        o.addProperty("discount_percent", mrp > price ? (int) Math.rint((mrp - price) * 100.0 / mrp) : 0);
        o.addProperty("rating", Math.round(rs.getDouble("rating") * 10) / 10.0);
        o.addProperty("reviews", rs.getInt("reviews"));
        o.addProperty("image", s(rs, "image"));
        o.addProperty("stock", stock);
        o.addProperty("in_stock", stock > 0);
        return o;
    }

    private static JsonArray listProducts(Request r, Connection c) throws SQLException {
        StringBuilder sql = new StringBuilder("SELECT " + PRODUCT_COLUMNS + " FROM shop_products WHERE 1 = 1");
        List<Object> args = new ArrayList<Object>();
        String q = r.query.get("q");
        if (q != null && !q.trim().isEmpty()) {
            // % and _ are wildcards in LIKE, so escape them to search for the characters themselves.
            String literal = q.trim().toLowerCase(Locale.ROOT).replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_");
            sql.append(" AND LOWER(name) LIKE ? ESCAPE '\\'");
            args.add("%" + literal + "%");
        }
        String category = r.query.get("category");
        if (category != null && !category.isEmpty()) {
            sql.append(" AND category = ?");
            args.add(category.toLowerCase(Locale.ROOT));
        }
        Integer min = queryInt(r, "min_price", 0, MAX_INT);
        if (min != null) {
            sql.append(" AND price >= ?");
            args.add(min);
        }
        Integer max = queryInt(r, "max_price", 0, MAX_INT);
        if (max != null) {
            sql.append(" AND price <= ?");
            args.add(max);
        }
        String inStock = r.query.get("in_stock");
        if (inStock != null) {
            String v = inStock.toLowerCase(Locale.ROOT);
            if (Arrays.asList("true", "1", "yes", "on", "t", "y").contains(v)) {
                sql.append(" AND stock > 0");
            } else if (Arrays.asList("false", "0", "no", "off", "f", "n").contains(v)) {
                sql.append(" AND stock = 0");
            } else {
                throw invalid("query", "in_stock", "Input should be a valid boolean");
            }
        }
        String sort = r.query.get("sort");
        String orderBy = SORTS.get(sort == null ? "id" : sort);
        if (orderBy == null) {
            throw invalid("query", "sort", "Unknown sort option");
        }
        sql.append(" ORDER BY ").append(orderBy);
        Integer limit = queryInt(r, "limit", 1, 100);
        if (limit != null) {
            sql.append(" FETCH FIRST ").append(limit.intValue()).append(" ROWS ONLY");
        }
        JsonArray out = new JsonArray();
        try (PreparedStatement ps = Db.ps(c, sql.toString(), args.toArray()); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                out.add(productJson(rs));
            }
        }
        return out;
    }

    private static JsonObject product(Connection c, int productId) throws SQLException {
        try (PreparedStatement ps = Db.ps(c, "SELECT " + PRODUCT_COLUMNS + " FROM shop_products WHERE id = ?", productId);
                ResultSet rs = ps.executeQuery()) {
            if (!rs.next()) {
                throw new ApiException(404, "Product not found");
            }
            return productJson(rs);
        }
    }

    private static JsonArray categories(Connection c) throws SQLException {
        Map<String, Integer> counts = new HashMap<String, Integer>();
        try (PreparedStatement ps = Db.ps(c, "SELECT category, COUNT(*) FROM shop_products GROUP BY category"); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                counts.put(rs.getString(1), rs.getInt(2));
            }
        }
        JsonArray out = new JsonArray();
        for (String[] cat : CATEGORIES) {
            JsonObject o = new JsonObject();
            o.addProperty("slug", cat[0]);
            o.addProperty("name", cat[1]);
            o.addProperty("icon", cat[2]);
            o.addProperty("count", counts.containsKey(cat[0]) ? counts.get(cat[0]) : 0);
            out.add(o);
        }
        return out;
    }

    // ------------------------------------------------------------------ cart
    private static JsonObject cart(Connection c, int userId) throws SQLException {
        String sql = "SELECT ci.product_id, p.name, p.price, ci.quantity FROM shop_cart_items ci "
                + "JOIN shop_products p ON p.id = ci.product_id WHERE ci.user_id = ? ORDER BY ci.id";
        JsonArray items = new JsonArray();
        long subtotal = 0;
        try (PreparedStatement ps = Db.ps(c, sql, userId); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                long line = (long) rs.getInt("price") * rs.getInt("quantity");
                JsonObject o = new JsonObject();
                o.addProperty("product_id", rs.getInt("product_id"));
                o.addProperty("name", s(rs, "name"));
                o.addProperty("unit_price", rs.getInt("price"));
                o.addProperty("quantity", rs.getInt("quantity"));
                o.addProperty("line_total", line);
                items.add(o);
                subtotal += line;
            }
        }
        JsonObject out = new JsonObject();
        out.add("items", items);
        out.addProperty("subtotal", subtotal);
        return out;
    }

    private static JsonObject setQuantity(Connection c, int userId, int productId, int quantity, boolean add) throws SQLException {
        int stock = product(c, productId).get("stock").getAsInt();
        Integer current = null;
        try (PreparedStatement ps = Db.ps(c, "SELECT quantity FROM shop_cart_items WHERE user_id = ? AND product_id = ?", userId, productId);
                ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                current = rs.getInt(1);
            }
        }
        if (current == null && !add) {
            throw new ApiException(404, "Product is not in the cart");
        }
        long wanted = (long) quantity + (current != null && add ? current : 0);
        if (wanted > stock) {
            throw new ApiException(409, "Only " + stock + " in stock");
        }
        try {
            if (current == null) {
                Db.update(c, "INSERT INTO shop_cart_items (id, user_id, product_id, quantity) VALUES (?, ?, ?, ?)",
                        Db.nextId(c, "cart_items"), userId, productId, (int) wanted);
            } else {
                Db.update(c, "UPDATE shop_cart_items SET quantity = ? WHERE user_id = ? AND product_id = ?", (int) wanted, userId, productId);
            }
        } catch (SQLIntegrityConstraintViolationException e) { // two requests added the same product at the same moment
            throw new ApiException(409, "The cart was changed by another request. Please try again");
        }
        return cart(c, userId);
    }

    // ------------------------------------------------------------------ coupons and checkout
    private static long discount(Connection c, String code, long subtotal) throws SQLException {
        String sql = "SELECT kind, amount, min_order, active, expires_at FROM shop_coupons WHERE code = ?";
        try (PreparedStatement ps = Db.ps(c, sql, code.trim().toUpperCase(Locale.ROOT)); ResultSet rs = ps.executeQuery()) {
            if (!rs.next()) {
                throw new ApiException(400, "Coupon not found");
            }
            if (rs.getInt("active") != 1) {
                throw new ApiException(400, "Coupon is not active");
            }
            Timestamp expires = rs.getTimestamp("expires_at");
            if (expires != null && expires.toLocalDateTime().isBefore(LocalDateTime.now(ZoneOffset.UTC))) {
                throw new ApiException(400, "Coupon has expired");
            }
            if (subtotal < rs.getInt("min_order")) {
                throw new ApiException(400, "Coupon needs a minimum order of " + rs.getInt("min_order"));
            }
            long amount = rs.getInt("amount");
            return "percent".equals(rs.getString("kind")) ? subtotal * amount / 100 : Math.min(amount, subtotal);
        }
    }

    private static Result validateCoupon(Request r, Connection c) throws SQLException {
        JsonObject u = user(r, c);
        String code = strField(body(r), "code", true);
        long subtotal = cart(c, id(u)).get("subtotal").getAsLong();
        if (subtotal == 0) {
            throw new ApiException(400, "Cart is empty");
        }
        long d = discount(c, code, subtotal);
        JsonObject o = new JsonObject();
        o.addProperty("code", code.trim().toUpperCase(Locale.ROOT));
        o.addProperty("subtotal", subtotal);
        o.addProperty("discount", d);
        o.addProperty("total", subtotal - d);
        return ok(o);
    }

    private static JsonObject shipping(JsonObject body) {
        JsonElement e = body.get("shipping");
        if (e == null || !e.isJsonObject()) {
            throw invalid("body", "shipping", e == null ? "Field required" : "Input should be a valid object");
        }
        JsonObject in = e.getAsJsonObject();
        String email = strField(in, "email", true);
        if (email.length() > 255 || !EMAIL.matcher(email).matches()) {
            throw invalid("body", "shipping.email", "Enter a valid email address");
        }
        JsonObject out = new JsonObject();
        out.addProperty("email", email);
        out.addProperty("full_name", text(in, "full_name", 100, false));
        out.addProperty("line1", text(in, "line1", 200, false));
        out.addProperty("line2", text(in, "line2", 200, true));
        out.addProperty("city", text(in, "city", 100, false));
        String state = strField(in, "state", true);
        if (!STATES.contains(state)) {
            throw invalid("body", "shipping.state", "Unknown state");
        }
        out.addProperty("state", state);
        String pin = strField(in, "postal_code", true);
        if (!PIN.matcher(pin).matches()) {
            throw invalid("body", "shipping.postal_code", "Enter a 6-digit PIN code");
        }
        out.addProperty("postal_code", pin);
        String country = strField(in, "country", false);
        if (country == null) {
            country = "India";
        }
        if (!COUNTRIES.contains(country)) {
            throw invalid("body", "shipping.country", "We only deliver in India");
        }
        out.addProperty("country", country);
        return out;
    }

    private static Result checkout(Request r, Connection c) throws SQLException {
        JsonObject u = user(r, c);
        JsonObject b = body(r);
        String card = strField(b, "card_number", true);
        if (!CARD.matcher(card).matches()) {
            throw invalid("body", "card_number", "Enter a 16-digit card number");
        }
        String coupon = strField(b, "coupon_code", false);
        JsonObject ship = shipping(b);
        int userId = id(u);

        // product_id, quantity, unit price, name: read once, used for the stock update and the order lines
        List<Object[]> lines = new ArrayList<Object[]>();
        String sql = "SELECT ci.product_id, ci.quantity, p.price, p.name FROM shop_cart_items ci "
                + "JOIN shop_products p ON p.id = ci.product_id WHERE ci.user_id = ? ORDER BY ci.id";
        long subtotal = 0;
        try (PreparedStatement ps = Db.ps(c, sql, userId); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lines.add(new Object[] {rs.getInt(1), rs.getInt(2), rs.getInt(3), s(rs, "name")});
                subtotal += (long) rs.getInt(2) * rs.getInt(3);
            }
        }
        if (lines.isEmpty()) {
            throw new ApiException(400, "Cart is empty");
        }
        long d = coupon == null ? 0 : discount(c, coupon, subtotal);
        if (DECLINED_CARD.equals(card)) {
            throw new ApiException(402, "Payment declined");
        }

        // Claim the cart first. If another checkout for this user got there first the rows are already gone
        // and this request stops, so one cart can only ever become one order.
        if (Db.update(c, "DELETE FROM shop_cart_items WHERE user_id = ?", userId) != lines.size()) {
            throw new ApiException(409, "This cart is already being checked out");
        }
        // Take stock with a guarded UPDATE so two buyers cannot both get the last unit.
        // Products are updated in id order so that two checkouts can never wait on each other in a cycle.
        List<Object[]> byProduct = new ArrayList<Object[]>(lines);
        Collections.sort(byProduct, new Comparator<Object[]>() {
            @Override
            public int compare(Object[] x, Object[] y) {
                return ((Integer) x[0]).compareTo((Integer) y[0]);
            }
        });
        for (Object[] line : byProduct) {
            if (Db.update(c, "UPDATE shop_products SET stock = stock - ? WHERE id = ? AND stock >= ?", line[1], line[0], line[1]) != 1) {
                throw new ApiException(409, "Not enough stock for " + line[3]);
            }
        }
        int orderId = Db.nextId(c, "orders");
        String code = coupon == null ? null : coupon.trim().toUpperCase(Locale.ROOT);
        Db.update(c, "INSERT INTO shop_orders (id, user_id, subtotal, discount, total, coupon_code, status, shipping, created_at) "
                + "VALUES (?, ?, ?, ?, ?, ?, 'paid', ?, ?)", orderId, userId, subtotal, d, subtotal - d, code, GSON.toJson(ship),
                Timestamp.valueOf(LocalDateTime.now(ZoneOffset.UTC)));
        for (Object[] line : lines) {
            Db.update(c, "INSERT INTO shop_order_items (id, order_id, product_id, name, unit_price, quantity) VALUES (?, ?, ?, ?, ?, ?)",
                    Db.nextId(c, "order_items"), orderId, line[0], line[3], line[2], line[1]);
        }
        return new Result(201, GSON.toJson(order(c, userId, orderId)));
    }

    // ------------------------------------------------------------------ orders
    private static final String ORDER_COLUMNS = "id, status, subtotal, discount, total, coupon_code, shipping, created_at";

    private static JsonObject orderJson(Connection c, ResultSet rs) throws SQLException {
        JsonObject o = new JsonObject();
        int orderId = rs.getInt("id");
        o.addProperty("id", orderId);
        o.addProperty("status", rs.getString("status"));
        o.addProperty("subtotal", rs.getLong("subtotal"));
        o.addProperty("discount", rs.getLong("discount"));
        o.addProperty("total", rs.getLong("total"));
        String code = rs.getString("coupon_code");
        o.add("coupon_code", code == null ? JsonNull.INSTANCE : new JsonPrimitive(code));
        o.addProperty("created_at", rs.getTimestamp("created_at").toLocalDateTime().format(ISO));
        String ship = rs.getString("shipping");
        JsonElement shipping = JsonNull.INSTANCE;
        if (ship != null && !ship.isEmpty()) {
            JsonObject parsed = JsonParser.parseString(ship).getAsJsonObject();
            if (!parsed.has("line2") || parsed.get("line2").isJsonNull()) {
                parsed.addProperty("line2", "");
            }
            shipping = parsed;
        }
        o.add("shipping", shipping);
        JsonArray items = new JsonArray();
        String sql = "SELECT product_id, name, unit_price, quantity FROM shop_order_items WHERE order_id = ? ORDER BY id";
        try (PreparedStatement ps = Db.ps(c, sql, orderId); ResultSet ir = ps.executeQuery()) {
            while (ir.next()) {
                JsonObject i = new JsonObject();
                i.addProperty("product_id", ir.getInt("product_id"));
                i.addProperty("name", s(ir, "name"));
                i.addProperty("unit_price", ir.getInt("unit_price"));
                i.addProperty("quantity", ir.getInt("quantity"));
                i.addProperty("line_total", (long) ir.getInt("unit_price") * ir.getInt("quantity"));
                items.add(i);
            }
        }
        o.add("items", items);
        return o;
    }

    private static JsonArray orders(Connection c, int userId) throws SQLException {
        JsonArray out = new JsonArray();
        String sql = "SELECT " + ORDER_COLUMNS + " FROM shop_orders WHERE user_id = ? ORDER BY id DESC";
        try (PreparedStatement ps = Db.ps(c, sql, userId); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                out.add(orderJson(c, rs));
            }
        }
        return out;
    }

    private static JsonObject order(Connection c, int userId, int orderId) throws SQLException {
        String sql = "SELECT " + ORDER_COLUMNS + " FROM shop_orders WHERE id = ? AND user_id = ?";
        try (PreparedStatement ps = Db.ps(c, sql, orderId, userId); ResultSet rs = ps.executeQuery()) {
            if (!rs.next()) {
                throw new ApiException(404, "Order not found");
            }
            return orderJson(c, rs);
        }
    }

    private static JsonObject cancelOrder(Connection c, int userId, int orderId) throws SQLException {
        order(c, userId, orderId); // 404 when it is not this user's order
        // Guarded update: of two cancel requests sent together only one changes the row, so stock is returned once.
        if (Db.update(c, "UPDATE shop_orders SET status = 'cancelled' WHERE id = ? AND user_id = ? AND status = 'paid'", orderId, userId) != 1) {
            throw new ApiException(409, "Order is already cancelled");
        }
        String sql = "SELECT product_id, quantity FROM shop_order_items WHERE order_id = ? ORDER BY product_id";
        List<int[]> back = new ArrayList<int[]>();
        try (PreparedStatement ps = Db.ps(c, sql, orderId); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                back.add(new int[] {rs.getInt(1), rs.getInt(2)});
            }
        }
        for (int[] b : back) {
            Db.update(c, "UPDATE shop_products SET stock = stock + ? WHERE id = ?", b[1], b[0]);
        }
        return order(c, userId, orderId);
    }
}
