package com.practiceshop;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/** Password hashing (PBKDF2-HMAC-SHA256, 50,000 rounds) and session tokens. */
public final class Passwords {
    private static final byte[] SALT = "shop-static-salt".getBytes(StandardCharsets.UTF_8);
    private static final int ROUNDS = 50000;
    private static final SecureRandom RANDOM = new SecureRandom();
    private static final char[] HEX = "0123456789abcdef".toCharArray();

    private Passwords() {
    }

    /** Written out with HmacSHA256 so it does not depend on which PBKDF2 providers the server's JDK ships. */
    public static String hash(String password) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(password.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            mac.update(SALT);
            byte[] u = mac.doFinal(new byte[] {0, 0, 0, 1});
            byte[] out = u.clone();
            for (int i = 1; i < ROUNDS; i++) {
                u = mac.doFinal(u);
                for (int j = 0; j < out.length; j++) {
                    out[j] ^= u[j];
                }
            }
            return hex(out);
        } catch (java.security.GeneralSecurityException e) {
            throw new IllegalStateException(e);
        }
    }

    public static boolean same(String a, String b) {
        return MessageDigest.isEqual(a.getBytes(StandardCharsets.UTF_8), b.getBytes(StandardCharsets.UTF_8));
    }

    public static String newToken() {
        byte[] b = new byte[24];
        RANDOM.nextBytes(b);
        return hex(b);
    }

    private static String hex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte x : bytes) {
            sb.append(HEX[(x >> 4) & 15]).append(HEX[x & 15]);
        }
        return sb.toString();
    }
}
