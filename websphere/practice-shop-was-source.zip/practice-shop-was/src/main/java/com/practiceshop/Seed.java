package com.practiceshop;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;

/** Puts the database back to the known starting state. The same data is in db/shop_oracle.sql. */
public final class Seed {
    private Seed() {
    }

    private static JsonObject load() {
        try (InputStream in = Seed.class.getResourceAsStream("/seed.json")) {
            if (in == null) {
                throw new IllegalStateException("seed.json is missing from the application");
            }
            Reader reader = new InputStreamReader(in, StandardCharsets.UTF_8);
            return JsonParser.parseReader(reader).getAsJsonObject();
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }

    public static void reset(Connection c) throws SQLException {
        JsonObject seed = load();
        // Children before parents, because of the foreign keys.
        for (String table : new String[] {"shop_order_items", "shop_orders", "shop_cart_items", "shop_tokens", "shop_coupons", "shop_products", "shop_users"}) {
            Db.update(c, "DELETE FROM " + table);
        }
        int maxUser = 0;
        for (JsonElement e : seed.getAsJsonArray("users")) {
            JsonObject u = e.getAsJsonObject();
            maxUser = Math.max(maxUser, u.get("id").getAsInt());
            Db.update(c, "INSERT INTO shop_users (id, email, name, password_hash) VALUES (?, ?, ?, ?)",
                    u.get("id").getAsInt(), str(u, "email"), str(u, "name"), str(u, "password_hash"));
        }
        JsonArray products = seed.getAsJsonArray("products");
        for (JsonElement e : products) {
            JsonObject p = e.getAsJsonObject();
            Db.update(c, "INSERT INTO shop_products (id, name, category, description, specs, price, mrp, stock, rating, reviews, image) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", p.get("id").getAsInt(), str(p, "name"), str(p, "category"), str(p, "description"),
                    str(p, "specs"), p.get("price").getAsInt(), p.get("mrp").getAsInt(), p.get("stock").getAsInt(),
                    p.get("rating").getAsDouble(), p.get("reviews").getAsInt(), str(p, "image"));
        }
        for (JsonElement e : seed.getAsJsonArray("coupons")) {
            JsonObject k = e.getAsJsonObject();
            String sql = "INSERT INTO shop_coupons (code, kind, amount, min_order, active, expires_at) VALUES (?, ?, ?, ?, ?, ?)";
            try (java.sql.PreparedStatement ps = Db.ps(c, sql, str(k, "code"), str(k, "kind"), k.get("amount").getAsInt(),
                    k.get("min_order").getAsInt(), k.get("active").getAsBoolean() ? 1 : 0, null)) {
                if (k.get("expires_at").isJsonNull()) {
                    ps.setNull(6, java.sql.Types.TIMESTAMP);
                } else {
                    ps.setTimestamp(6, Timestamp.valueOf(str(k, "expires_at")));
                }
                ps.executeUpdate();
            }
        }
        Db.update(c, "UPDATE shop_id_counters SET next_val = 1 WHERE name IN ('orders', 'order_items', 'cart_items')");
        Db.update(c, "UPDATE shop_id_counters SET next_val = ? WHERE name = 'users'", maxUser + 1);
    }

    private static String str(JsonObject o, String key) {
        return o.get(key).getAsString();
    }
}
