package com.practiceshop.dev;

import com.practiceshop.ShopServlet;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.seleniumhq.jetty9.server.Server;
import org.seleniumhq.jetty9.servlet.DefaultServlet;
import org.seleniumhq.jetty9.servlet.ServletContextHandler;
import org.seleniumhq.jetty9.servlet.ServletHolder;

/**
 * Test harness only; it is not part of the WAR. Runs the real servlet with the URL patterns from web.xml on an
 * embedded Jetty, against an in-memory H2 database in Oracle compatibility mode loaded from db/shop_oracle.sql.
 */
public final class DevServer {
    /** H2 has no UNISTR, so the Oracle script's UNISTR('...\2022...') calls are mapped to this. */
    public static String unistr(String s) {
        Matcher m = Pattern.compile("\\\\([0-9A-Fa-f]{4})").matcher(s);
        StringBuffer out = new StringBuffer();
        while (m.find()) {
            m.appendReplacement(out, Matcher.quoteReplacement(String.valueOf((char) Integer.parseInt(m.group(1), 16))));
        }
        m.appendTail(out);
        return out.toString();
    }

    public static void main(String[] args) throws Exception {
        int port = Integer.parseInt(args[0]);
        String contextPath = args[1];
        String root = args[2];
        String url = "jdbc:h2:mem:shop;MODE=Oracle;DB_CLOSE_DELAY=-1;LOCK_TIMEOUT=10000";
        System.setProperty("shop.jdbc.url", url);
        try (Connection c = DriverManager.getConnection(url); Statement st = c.createStatement()) {
            st.execute("CREATE ALIAS UNISTR FOR \"com.practiceshop.dev.DevServer.unistr\"");
            String script = new String(Files.readAllBytes(Paths.get(root, "db/shop_oracle.sql")), StandardCharsets.UTF_8);
            int n = 0;
            for (String stmt : script.replaceAll("(?m)^--.*$", "").split(";\\s*\\n")) {
                if (!stmt.trim().isEmpty()) {
                    st.execute(stmt.trim());
                    n++;
                }
            }
            System.out.println("Ran " + n + " statements from db/shop_oracle.sql");
        }
        String webXml = new String(Files.readAllBytes(Paths.get(root, "src/main/webapp/WEB-INF/web.xml")), StandardCharsets.UTF_8);
        ServletContextHandler ctx = new ServletContextHandler(ServletContextHandler.NO_SESSIONS);
        ctx.setContextPath(contextPath);
        ctx.setResourceBase(Paths.get(root, "build/war").toString());
        ctx.setWelcomeFiles(new String[] {"index.html"});
        ServletHolder api = new ServletHolder(new ShopServlet());
        Matcher m = Pattern.compile("<url-pattern>([^<]+)</url-pattern>").matcher(webXml);
        while (m.find()) {
            ctx.addServlet(api, m.group(1));
        }
        ctx.addServlet(new ServletHolder("default", DefaultServlet.class), "/");
        Server server = new Server(port);
        server.setHandler(ctx);
        server.start();
        System.out.println("Practice Shop running at http://127.0.0.1:" + port + contextPath);
        server.join();
    }
}
